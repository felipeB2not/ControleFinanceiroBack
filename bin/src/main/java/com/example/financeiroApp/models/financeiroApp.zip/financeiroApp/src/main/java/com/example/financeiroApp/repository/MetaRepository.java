package com.example.financeiroApp.repository;

import com.example.financeiroApp.models.Meta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetaRepository extends JpaRepository<Meta, Integer> {

}
