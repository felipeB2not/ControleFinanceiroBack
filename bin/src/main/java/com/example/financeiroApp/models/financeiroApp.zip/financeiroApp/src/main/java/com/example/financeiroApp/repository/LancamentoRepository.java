package com.example.financeiroApp.repository;

import com.example.financeiroApp.models.Lancamento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LancamentoRepository extends JpaRepository<Lancamento, Long>{

}
